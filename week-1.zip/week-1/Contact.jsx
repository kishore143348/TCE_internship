import React from "contact";

function Contact(){
    return(
        <>
        <h1 className="text-primary">
            Bootstrap in node</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora ipsum cupiditate voluptatum. Esse facilis minima perspiciatis quo vitae culpa aliquid.</p></>
    )
    
}
export default Contact;