import React from "react";
const Body =()=>{
    return(
    <>
    <hr/>
    <h3>About Me</h3>
    <p>
    Netaji Subhash, a feature documentary film about Bose was released in 1947, it was directed by Chhotubhai Desai. Subhas Chandra is a 1966 Indian Bengali-language biographical film, directed by Pijush Basu. Neta Ji Subhash Chandra Bose is a 1966 Indian biographical drama film about Bose by Hemen Gupta
    </p>
    </>
    );
};
export default Body;