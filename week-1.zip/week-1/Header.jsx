import React from 'react'
import "./Header.css"
function Header(){

    return(
        <div id='box'>
         <h1>Subash chandr Bose</h1>
         <img src="https://images.edexlive.com/uploads/user/imagelibrary/2018/1/23/original/Netaji-Subash-Chandra-Bose1a.jpg" height={400}/>
         </div>
         );
};
export default Header