import React from "react";
import "Bootstrap/dist/css/bootstrap.min.css"

function Bootstrap(){
    return(
        <>
        <h1 className="text-primary">
            Bootstrap in node</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora ipsum cupiditate voluptatum. Esse facilis minima perspiciatis quo vitae culpa aliquid.</p></>
    )
    
}
export default Bootstrap;
