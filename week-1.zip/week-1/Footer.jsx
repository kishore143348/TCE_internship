import React,{Component} from 'react'

class Footer extends Component{
    render(){
     return(
        <>
        <hr/>
        <h3>Contact</h3>
        <p>
            <b>Mobile:</b>7676586643
        </p>
        <p>
            <b>Email:</b>kaushi@gmail.com
        </p>
        </>
        );
     }
}
export default Footer;